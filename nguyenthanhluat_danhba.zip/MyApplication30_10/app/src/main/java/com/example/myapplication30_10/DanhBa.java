package com.example.myapplication30_10;

import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.AndroidException;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication30_10.model.Contact;

import java.util.ArrayList;

public class DanhBa extends AppCompatActivity {

    private static final int REQUEST_CODE_ASK_PERMISSIONS = 1001;

    ListView lvDanhba;
    ArrayList<Contact>  dsDanhBa;
    ArrayAdapter<Contact> adapterDanhBa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_ba);
        addControl();
        showAllContactFromDevice();
    }

//    private void showAllContactFromDevice() {
//        // thông qua contacstcontract để lấy contact trong điện thoại
//        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
//        // trả về 1 cursor
//        Cursor cursor = getContentResolver().query(uri, null,null,null,null );
//        dsDanhBa.clear();
//        while (cursor.moveToNext()){
//            // lấy thông tin ten trong danh ba
//            String tencotname = ContactsContract.Contacts.DISPLAY_NAME;
//            // lấy thông tin sđt trong danh ba
//            String tencotphone = ContactsContract.CommonDataKinds.Phone.NUMBER;
//            // lấy vị trí cột trong dữ liệu
//            int vitricotname = cursor.getColumnIndex(tencotname);
//            int vitricotphone = cursor.getColumnIndex(tencotphone);
//            // lấy dữ liệu trong các cột ra
//            String name = cursor.getString(vitricotname);
//            String phone = cursor.getString(vitricotphone);
//            // đưa vào mảng
//            Contact contact = new Contact(name,phone);
//            dsDanhBa.add(contact);
//            adapterDanhBa.notifyDataSetChanged();
//        }
//    }
private void showAllContactFromDevice() {
    if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
        requestPermissions(new String[]{android.Manifest.permission.READ_CONTACTS}, REQUEST_CODE_ASK_PERMISSIONS);
        return;
    }
    // tiếp tục truy cập danh bạ nếu quyền đã được cấp
    Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
    Cursor cursor = getContentResolver().query(uri, null, null, null, null);
    if (cursor != null) {
        dsDanhBa.clear();
        while (cursor.moveToNext()) {
            String tencotname = ContactsContract.Contacts.DISPLAY_NAME;
            String tencotphone = ContactsContract.CommonDataKinds.Phone.NUMBER;
            int vitricotname = cursor.getColumnIndex(tencotname);
            int vitricotphone = cursor.getColumnIndex(tencotphone);
            String name = cursor.getString(vitricotname);
            String phone = cursor.getString(vitricotphone);
            Contact contact = new Contact(name, phone);
            dsDanhBa.add(contact);
            adapterDanhBa.notifyDataSetChanged();
        }
    }
}


    private void addControl() {
        lvDanhba =findViewById(R.id.lvDanhba);
        dsDanhBa = new ArrayList<>();
        adapterDanhBa = new ArrayAdapter<>(
                DanhBa.this, android.R.layout.simple_list_item_1,dsDanhBa
        );
        lvDanhba.setAdapter(adapterDanhBa);
    }
}