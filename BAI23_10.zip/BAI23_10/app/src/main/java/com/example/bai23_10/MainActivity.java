package com.example.bai23_10;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//import kotlinx.coroutines.android.AndroidExceptionPreHandler;

public class MainActivity extends AppCompatActivity {
    Button button;
    EditText editname, editpass;
    CheckBox checkBox;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        anhxa();
        sharedPreferences = getSharedPreferences("datalogin",MODE_PRIVATE);
        editname.setText(sharedPreferences.getString("tai khoan",""));
        editpass.setText(sharedPreferences.getString("mat khau",""));
        checkBox.setChecked(sharedPreferences.getBoolean("checked",false));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = editname.getText().toString().trim();
                String mk = editpass.getText().toString().trim();
                if (user.equals("thanhluat")&& mk.equals("123")){
                    Toast.makeText(MainActivity.this,"dang nhap thanh cong", Toast.LENGTH_SHORT).show();
                    if (checkBox.isChecked()){
                        SharedPreferences.Editor editor=sharedPreferences.edit();
                        editor.putString("tai khoan",user);
                        editor.putString("mat khau", mk);
                        editor.putBoolean("checked", true);
                        editor.commit();
                    }
                    else {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.remove("tai khoan");
                        editor.remove("mat khau");
                        editor.remove("checked");
                        editor.commit();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "loi dang nhap", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private void anhxa() {
        button =(Button) findViewById(R.id.button);
        editname=(EditText) findViewById(R.id.name);
        editpass=(EditText) findViewById(R.id.pass);
        checkBox=(CheckBox) findViewById(R.id.checkBox);
    }
}